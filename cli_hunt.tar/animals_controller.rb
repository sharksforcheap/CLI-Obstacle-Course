class AnimalsController < ApplicationController
end
