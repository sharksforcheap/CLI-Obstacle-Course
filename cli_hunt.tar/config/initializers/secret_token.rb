# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
CliScavengerHunt::Application.config.secret_token = '5f64a1d4479f8fc0ed352f77f115f81b0e88d633261cae9c3e68bca5328fb2856f9498808cc224f16f00f61e04582c93a0ae57d2116e6ae39a11621fffadb9ec'
