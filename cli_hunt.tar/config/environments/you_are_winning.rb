#!/user.bin/env ruby
puts ""
puts ""
puts "your secret instructions are:"
puts "put all your previous commands into a text file and email it to staff@devbootcamp.com"
puts ""
puts ""
