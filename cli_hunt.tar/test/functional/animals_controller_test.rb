require 'test_helper'

class AnimalsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
