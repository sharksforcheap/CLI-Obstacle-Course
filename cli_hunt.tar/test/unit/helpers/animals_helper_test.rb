require 'test_helper'

class AnimalsHelperTest < ActionView::TestCase
end
