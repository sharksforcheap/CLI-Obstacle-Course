require 'test_helper'

class StaticPagesHelperTest < ActionView::TestCase
end
