class SchoolsController < ApplicationController
end
