class CarsController < ApplicationController
	def new
	end
end
