module ApplicationHelper
	def bootinator(name)
		"you found me, #{name}!"
	end
end
