class PeopleController < ApplicationController
end
